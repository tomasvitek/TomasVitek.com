
#### Design a robotic worm for surgical applications

## Abstract

## Introduction & Motivation

Endoscopy is a process of looking inside a human body with a thin long flexible instrument (called endoscope). Endoscopy is very important part of health prevention as well as a useful tool which helps surgeons during operations. The existing endoscopes bring quite substantial discomfort to patients, because they require to be pushed to their position.

Thomas [1] researched and built a hardware project of an earthworm-like robot which uses peristaltic locomotion to move. This robot could be used in surgical application such as endoscopy.

This project will focus on improving this project by researching and developing control algorithms for the existing developed hardware robot. 

## Scope

The scope of this project is to built upon already developed worm-like robot created by T [1] and to research and implement software algorithms for controlling the provided hardware solution. 

While there are many possible tasks which the robot could be performing autonomously, this project will focus on researching and implementing only basic and some more complicated movements. This is because of the limited time scope of this project. Movements to research and implement have been selected to provide a good foundation for possible future development. 

## Aim & Objectives

The main aim of the project is to research, test and develop functioning algorithm(s) which will control a worm-like robot and allow it to autonomously move with a continuous interaction with an human operator. 

To achieve this aim several objectives need to be completed:

### Model the robot in SIMULINK

A model of a feedback control system representing the worm-like robot needs to be created to allow for fast and precise simulation of different algorithms to solve a particular problem. This modeling will be done in Simulink, which is a toolbox for MatLab software, specifically developed to enable modeling of feedback control systems.

### Research basic forward movement

Using the created model a variety of different algorithms and possible solutions should be researched and tested to find an efficient way how to make the worm-like robot move forward on a flat surface. Implementing basic forward movement is essential for solving more complicated movements, because those will require using forward movement quite frequently. 

### Implementation and testing of basic forward movement

Once an effective algorithm for basic forward movement is found, it should be implemented using a single-board micro-controller Arduino. 

After implementing basic forward movement, the robot should be tested properly to make sure that the algorithm works. If needed required adjustments should be done. 

### Research, implement and test backward movement

Once forward movement is implemented and tested, the algorithm should be modified to allow movement backward as well. The modified version should be simulated in the model to test, if it will work. After confirming that it should work, the algorithm should be implemented in the robot and tested. 

### Researching algorithms for more complicated movements 

After implementing and testing the basic movements, more complex movements such as turning and moving forward and backward in tubes with different diameter should be researched. 

This will allow the robot to actually move in real and more complicated environments. 

### Implementing and testing more complicated movements

After finding proper algorithms allowing above mentioned complex movements, the algorithms should be implemented and tested. 

### Researching other potential improvements 

If the time scope of this project will allow it, after implementing all above mentioned objectives, further improvements can be researched and considered. 

## Used platforms & tools

### Software

- MatLab and Simulink to model the robot
- Arduino IDE for implementing the chosen algorithms

### Hardware

- Single-board micro-controller Arduino

## Plan

The plan for this project will 

## Gantt chart