public class Question {
	
	private int mark;
	private String text;
	
	
	public Question(int mark) {
		
		this.mark = mark;
	}
	
	public Question(int mark, String text) {
		
		this.mark = mark;
		this.text = text;
	}
	
	
	public int readMark() {
		
		return mark;
		
	}

	public void giveMark(int mark) {
		
		this.mark = mark;
	
	}
	
	public String getText(){
		return text;
	}
	
	public void setText(String text){
		this.text = text;
	}

}