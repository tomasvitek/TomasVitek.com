
/**
 * Write a description of class NumericalQ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BooleanQuestion extends Question
{
    private boolean answer;
    private boolean correctAnswer;
    
    public BooleanQuestion(String contents, boolean correctAnswer, int marks)
    {
            super(contents,marks);
            this.correctAnswer = correctAnswer;
            
    }
    
    public void setAnswer(boolean answer){
        this.answer = answer;
    }
    
    public int checkAnswer() {
        if (answer == correctAnswer) return getMarks();
        return 0;
    }
}
