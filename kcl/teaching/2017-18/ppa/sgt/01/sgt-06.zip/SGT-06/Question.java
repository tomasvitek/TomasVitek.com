

public class Question
{
    private String questionContents;
    private int marks;

    /**
     * Constructor for objects of class Question
     */
    public Question(String contents, int marks)
    {
            questionContents = contents;
            this.marks = marks;
    }

    public String getQuestion(){
        return questionContents;
    }
    
    public int getMarks() {
        return marks;
    }
  
}
