
/**
 * Write a description of class ExamMarker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ExamMarker
{
    public void markExam(Exam ex) {
        // int totalPossibleMarks = ??;
        int totalMarks = ex.markQuestions();
        System.out.println(totalMarks);
        
        
    }
}
