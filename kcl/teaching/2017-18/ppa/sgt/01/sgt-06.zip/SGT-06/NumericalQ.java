
/**
 * Write a description of class NumericalQ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NumericalQ extends Question
{
    private float answer;
    private float correctAnswer;
    
    public NumericalQ(String contents, float correctAnswer, int marks)
    {
            super(contents,marks);
            this.correctAnswer = correctAnswer;
            
    }
    
    public void setAnswer(float answer){
        this.answer = answer;
    }
    
    public int checkAnswer() {
        if (answer == correctAnswer) return getMarks();
        return 0;
    }
}
