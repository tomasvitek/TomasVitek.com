import java.util.ArrayList;
/**
 * Write a description of class Exams here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Exam
{
    // instance variables - replace the example below with your own
    private ArrayList<Question> questionsList = new ArrayList<Question>();

    /**
     * Constructor for objects of class Exams
     */
    public Exam()
    {
        //questionsList = questionListInput;
        
        questionsList.add(new NumericalQ("2+2",4f,10));
        questionsList.add(new BooleanQuestion("Do we exist?",true, 20));
        
        showQuestions();
        
        setAnswer(3f, 0);
        setAnswer(true, 1);
        
        new ExamMarker().markExam(this);
    }

    public void showQuestions(){
        for (Question question : questionsList){
            System.out.println(question.getQuestion());
        }
    }
    
    public void setAnswer(float answer,int index){
        NumericalQ num = (NumericalQ)questionsList.get(index);
        num.setAnswer(answer);
    }
    
    public void setAnswer(boolean answer,int index){
        BooleanQuestion b = (BooleanQuestion)questionsList.get(index);
        b.setAnswer(answer);
    }
    
    public int markQuestions() {
        int total = 0;
        for (Question question : questionsList){
            if (question.getClass().equals(NumericalQ.class)) {
                total += ((NumericalQ)question).checkAnswer();
            }
            if (question.getClass().equals(BooleanQuestion.class)) {
                total += ((BooleanQuestion)question).checkAnswer();
            }
        }
        return total;
    }
}
