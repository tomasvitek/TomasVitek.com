
/**
 * Write a description of class NumericalQuestion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NumericalQuestion extends ExamQuestion
{
    private int answer;
    private int correct;
    
    public NumericalQuestion(String qText, int mark, int correct)
    {
        super(qText, mark);
        
        this.correct = correct;
    }
    
    public void setAnswer(int newAnswer)
    {
        answer = newAnswer;
    }
    
    public int mark() {
        if (answer == correct) return getMaxMark();
        else return 0;
    }
}
