
/**
 * Write a description of class BooleanQuestion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BooleanQuestion extends ExamQuestion
{
    // instance variables - replace the example below with your own
    private boolean answer;
    
    private boolean correct;

    /**
     * Constructor for objects of class BooleanQuestion
     */
    public BooleanQuestion(String qText, int mark, boolean correct)
    {
        // initialise instance variables
       super(qText, mark);
       
       this.correct = correct;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void setAnswer(boolean newAnswer)
    {
        // put your code here
        answer =newAnswer;
    }
    
    public int mark() {
        if (answer == correct) return getMaxMark();
        else return 0;
    }
}
