
/**
 * Write a description of class MultipleChoice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MultipleChoice extends ExamQuestion
{
    // instance variables - replace the example below with your
    private String[] allChoices;
    private int answer;
    private int correct;
    /**
     * Constructor for objects of class MultipleChoice
     */
    public MultipleChoice(String qText, int mark, String[] choice, int correct)
    {
        super(qText, mark);
        allChoices = choice;
        this.correct = correct;
    }
    

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void setAnswer(int newAnswer)
    {
        if (newAnswer <0 || newAnswer > allChoices.length-1){
            System.out.println("Wrong choice!");
        }
        else {
            answer = newAnswer;
        }
    }
    
    public String getText() {
        String p = super.getText();
        
        for (int i = 0; i < allChoices.length; i++) {
          p += i + ") " + allChoices[i] + "\n";
        }
        
        return p + "\n";
        
    }
    
    public int mark() {
        if (answer == correct) return getMaxMark();
        else return 0;
    }
    
}

