public class Exam
{
    private NumericalQuestion q1;
    private BooleanQuestion q2;
    private MultipleChoice q3;
    
    public Exam() {
        q1 = new NumericalQuestion("2+2", 2, 4);
        q2 = new BooleanQuestion("Big Ben is in London", 5, true);
        String[] options = {"red", "dolphin", "cake", "pen"};
        q3 = new MultipleChoice("Which is a colour?", 7, options, 0);
    }
    
    public void printQs() {        
        System.out.println(q1.getText());
        System.out.println(q2.getText());
        System.out.println(q3.getText());
     
    }
    
    public void markExam() {
        int marks = q1.mark() + q2.mark() + q3.mark();
        int maxMarks = q1.getMaxMark() + q2.getMaxMark() + q3.getMaxMark();
        System.out.print(marks);
    }
    
    public void answerQ1(int a) {
        q1.setAnswer(a);
    }
    
    public void answerQ2(boolean a) {
        q2.setAnswer(a);
    }
    
    public void answerQ3(int a) {
        q3.setAnswer(a);
    }
    
}
