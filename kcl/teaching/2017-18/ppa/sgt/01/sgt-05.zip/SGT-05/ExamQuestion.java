
/**
 * Write a description of class ExamQuestion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ExamQuestion
{
    private String questionText;
    private int mark;
    
    public ExamQuestion(String qText, int qMark)
    {
        questionText = qText;
        mark = qMark;
    }
    
    public String getText() {
        return questionText + "\n";
    }
    
    public int getMaxMark() {
        return mark;
    }
}
