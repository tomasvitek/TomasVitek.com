import dojo3.PlayerGrid;
import java.awt.Color;
import java.util.Random;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class MazeView extends PlayerGrid
{
    public static final int ROWS = 30;
    public static final int COLS = 30;
    
    public static final int MAZE_HOW_FULL = 20;
    
    private int exitX, exitY;
    private int playerX, playerY;
    
    private Random r = new Random();
    
    public MazeView() {
        super(ROWS, COLS, 400, 400);
        generateMaze();
        addKeyListener(new PlayerMover());
        setVisible(true);
    }
    
    private void generateMaze() {
        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                if (r.nextInt(100) < MAZE_HOW_FULL) {
                    fillSquare(y, x, Color.BLACK);
                }
            }
        }
        
        while (true) {
            exitX = r.nextInt(COLS);
            exitY = r.nextInt(ROWS);
            if (!squareFilled(exitY, exitX).equals(Color.BLACK)) {
                break;
            }    
        }
        fillSquare(exitY, exitX, Color.GREEN);
        
        while (true) {
            playerX = r.nextInt(COLS);
            playerY = r.nextInt(ROWS);
            if (!squareFilled(playerY, playerX).equals(Color.BLACK)
                    && !squareFilled(playerY, playerX).equals(Color.GREEN)) {
                break;
            }    
        }
        fillSquare(playerY, playerX, Color.RED);        
    }
    
    private class PlayerMover implements KeyListener {
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:
                    movePlayer(playerY-1, playerX);
                    break;
                case KeyEvent.VK_DOWN:
                    movePlayer(playerY+1, playerX);
                    break;
                case KeyEvent.VK_LEFT:
                    movePlayer(playerY, playerX-1);
                    break;
                case KeyEvent.VK_RIGHT:
                    movePlayer(playerY, playerX+1);                    
                    break;
            }
            
        }
        
        private void movePlayer(int newY, int newX) {
            // cant go over the edge
            if (newY < 0 || newX < 0) return;
            if (newY >= ROWS || newX >= COLS) return;
            // obstacle
            if (squareFilled(newY, newX).equals(Color.BLACK)) return;

            fillSquare(playerY, playerX, Color.GRAY);
            fillSquare(newY, newX, Color.RED); 
            playerX = newX;
            playerY = newY;
            
            // exit
            if (newY == exitY && newX == exitX) {
                JOptionPane.showMessageDialog(MazeView.this, "Yay!");
            }
        }

        public void keyReleased(KeyEvent e) {} // not used

        public void keyTyped(KeyEvent e) {} // not used
        
    }
    
}
