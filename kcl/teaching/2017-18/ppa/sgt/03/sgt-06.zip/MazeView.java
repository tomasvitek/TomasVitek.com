import dojo3.PlayerGrid;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import java.util.Random;

/**
 * Write a description of class MazeGame here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MazeView extends PlayerGrid
{
   public static final int MAZE_WIDTH = 20;
   public static final int MAZE_HEIGHT = 20;
   
   public static final int MAZE_OBSTACLE_COVERAGE = 20; // in %
   
   private int playerX, playerY;
   private int exitX, exitY;
   
   public MazeView() {
       super(MAZE_HEIGHT, MAZE_WIDTH, 500, 500);
       generateMaze();
       addKeyListener(new PlayerMover());
       setVisible(true);
   }
   
   private void generateMaze() {
       Random r = new Random();
       for (int x = 0; x < MAZE_WIDTH; x++) {
           for (int y = 0; y < MAZE_HEIGHT; y++) {
               if (r.nextInt(100) < MAZE_OBSTACLE_COVERAGE) {
                  fillSquare(y, x, Color.BLACK); 
               }
           }
       }
       
       while (true) {
           exitX = r.nextInt(MAZE_WIDTH);
           exitY = r.nextInt(MAZE_HEIGHT);
           if (!squareFilled(exitY, exitX).equals(Color.BLACK)) {
               break;
           }
       }
       fillSquare(exitY, exitX, Color.GREEN); 
       
       while (true) {
           playerX = r.nextInt(MAZE_WIDTH);
           playerY = r.nextInt(MAZE_HEIGHT);
           if (!squareFilled(playerY, playerX).equals(Color.BLACK)
                && !squareFilled(playerY, playerX).equals(Color.GREEN)) {
               break;
           }
       }
       fillSquare(playerY, playerX, Color.RED); 
   }
   
   private boolean canPlayerMoveTo(int x, int y) {
       // check if next move if valid
       if (x < 0 || y < 0) return false;
       if (x > MAZE_WIDTH || y > MAZE_HEIGHT) return false;       
       if (squareFilled(y, x).equals(Color.BLACK)) return false;    
       
       // check if next move if winning move
       if (willPlayerWin(x, y)) {
           JOptionPane.showMessageDialog(null, "Yay!");
       }
       return true;
   }

   private boolean willPlayerWin(int x, int y) {
       if (squareFilled(y, x).equals(Color.GREEN)) return true;    
       return false;
   }
   
   private class PlayerMover implements KeyListener {
       public void keyTyped(KeyEvent e) {}
       public void keyReleased(KeyEvent e) {}
        
        @Override
        public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
            	if (canPlayerMoveTo(playerX-1, playerY)) {
            	    fillSquare(playerY, playerX, Color.GRAY); 
            	    playerX -= 1;
            	    fillSquare(playerY, playerX, Color.RED); 
            	}
                break;
            case KeyEvent.VK_RIGHT:
            	if (canPlayerMoveTo(playerX+1, playerY)) {
            	    fillSquare(playerY, playerX, Color.GRAY); 
            	    playerX += 1;
            	    fillSquare(playerY, playerX, Color.RED); 
            	}
                break;
            case KeyEvent.VK_UP:
            	if (canPlayerMoveTo(playerX, playerY-1)) {
            	    fillSquare(playerY, playerX, Color.GRAY); 
            	    playerY -= 1;
            	    fillSquare(playerY, playerX, Color.RED); 
            	}
                break;
            case KeyEvent.VK_DOWN:
            	if (canPlayerMoveTo(playerX, playerY+1)) {
            	    fillSquare(playerY, playerX, Color.GRAY); 
            	    playerY += 1;
            	    fillSquare(playerY, playerX, Color.RED); 
            	}
                break;
        }
    }
       
   }
   
}

