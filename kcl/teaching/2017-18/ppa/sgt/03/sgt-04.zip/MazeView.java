import dojo3.PlayerGrid;
import java.awt.Color;
import java.util.Random;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class MazeView extends PlayerGrid
{
    public static final int COLS = 30;
    public static final int ROWS = 30;
    
    public static final int MAZE_FULL = 20;
    
    private int exitX, exitY;
    private int playerX, playerY;
    
    private Random r = new Random();
    
    public MazeView() {
        super(ROWS, COLS, 800, 800);
        generateMaze();
        addKeyListener(new PlayerMover());
        setVisible(true);
    }
   
    private void generateMaze() {
        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                if (r.nextInt(100) < MAZE_FULL) {
                    fillSquare(y, x, Color.BLACK);
                }
            }
        }
        
        while (true) {
            exitX = r.nextInt(COLS);
            exitY = r.nextInt(ROWS);
            if (!squareFilled(exitY, exitX).equals(Color.BLACK)) {
                break;
            }
        }
        fillSquare(exitY, exitX, Color.GREEN);
        
        while (true) {
            playerX = r.nextInt(COLS);
            playerY = r.nextInt(ROWS);
            if (!squareFilled(playerY, playerX).equals(Color.BLACK)
                   && !squareFilled(playerY, playerX).equals(Color.GREEN)) {
                break;
            }
        }
        fillSquare(playerY, playerX, Color.RED);
    }
    
    private class PlayerMover implements KeyListener {

        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:
                    movePlayer(playerX, playerY-1);
                    break;
                case KeyEvent.VK_DOWN:
                    movePlayer(playerX, playerY+1);
                    break;
                case KeyEvent.VK_LEFT:
                    movePlayer(playerX-1, playerY);
                    break;
                case KeyEvent.VK_RIGHT:
                    movePlayer(playerX+1, playerY);
                    break;
            }
        }
        
        private void movePlayer(int x, int y) {
            // edge detection
            if (x < 0 || y < 0) return;
            if (x >= COLS || y >= ROWS) return;
            // obstacle
            if (squareFilled(y, x).equals(Color.BLACK)) return;
           
            fillSquare(playerY, playerX, Color.GRAY);
            fillSquare(y, x, Color.RED);
            playerX = x;
            playerY = y;

            // check for winning
            if (x == exitX && y == exitY) {
                JOptionPane.showMessageDialog(null, "Yay");
                System.exit(0);
            }
        }
        
        // not used
        public void keyReleased(KeyEvent e) {}
        public void keyTyped(KeyEvent e) {}
    }
}
