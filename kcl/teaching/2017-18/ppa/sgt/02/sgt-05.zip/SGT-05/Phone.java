import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Phone extends JFrame
{
    private JLabel numbersLabel;
    private String numbers = "";
    
    private void renderNumbers() {
        numbersLabel.setText(numbers);
    }
    
    private void addToNumbers(String number) {
        numbers += number;
        renderNumbers();
    }
    
    public Phone() {
        setSize(300, 400);

        JPanel north = new JPanel();
        JPanel center = new JPanel();
        JPanel south = new JPanel();
        
        setLayout(new BorderLayout());
        
        add(north, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        
        // south
        
        JButton favButton = new JButton("(f)");
        JButton recButton = new JButton("(r)");        
        JButton conButton = new JButton("(c)");        
        JButton keyButton = new JButton("(k)");        
        JButton voiButton = new JButton("(v)");        
        
        south.setLayout(new GridLayout(1, 5));
        south.add(favButton);
        south.add(recButton);
        south.add(conButton);
        south.add(keyButton);
        south.add(voiButton);
        
        // north
        
        JButton addButton = new JButton("(+)");
        JButton delButton = new JButton("(<)");
        numbersLabel = new JLabel();
        renderNumbers();
        
        north.setLayout(new BorderLayout());
        north.add(addButton, BorderLayout.WEST);
        north.add(delButton, BorderLayout.EAST);
        north.add(numbersLabel, BorderLayout.CENTER);
        
        // center
        
        center.setLayout(new GridLayout(5, 3));
        
        JButton[] numberButtons = new JButton[10];
        
        ActionListener action =  new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton)e.getSource();
                addToNumbers(source.getText());
            }
        };
        
        for (int i = 1; i < 10; i++) {
            numberButtons[i] = new JButton(""+i);
            numberButtons[i].addActionListener(action);
            center.add(numberButtons[i]);
        }
        
        JButton starButton = new JButton("*");
        starButton.addActionListener(action);
        JButton hashButton = new JButton("#");
        hashButton.addActionListener(action);
        numberButtons[0] = new JButton("0");
        numberButtons[0].addActionListener(action);
        JButton callButton = new JButton("call");
        
        center.add(starButton);
        center.add(numberButtons[0]);
        center.add(hashButton);
        center.add(new JLabel());
        center.add(callButton);
        
        
        setVisible(true);
    }
    
  
}
