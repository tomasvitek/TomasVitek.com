import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;

public class Phone extends JFrame
{
    private String numbers = "";
    private JLabel numberLabel;
    
    public Phone() {
        setLayout(new BorderLayout());
        setTitle("O2-UK   19:26    33%");
        setSize(400, 500);
        
        // create north panel
        JPanel north = new JPanel();
        north.setLayout(new BorderLayout());        
        add(north, BorderLayout.NORTH);
        
        // create components for north
        JButton addButton = new JButton("(+)");
        JButton delButton = new JButton("(<)");
        numberLabel = new JLabel();
        renderNumbers();
        
        north.add(addButton, BorderLayout.WEST);
        north.add(delButton, BorderLayout.EAST);
        north.add(numberLabel, BorderLayout.CENTER);
  
        
        // create numbers panel
        JPanel numbers = new JPanel();
        numbers.setLayout(new GridLayout(5, 3));
        add(numbers, BorderLayout.CENTER);
        
        ActionListener addNumber = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JButton source = (JButton)e.getSource();
                    addToNumbers(source.getText());
                }   
            };
        
        JButton[] numberButtons = new JButton[10];
        for (int i = 1; i < 10; i++) {
            numberButtons[i] = new JButton(""+i);
            numberButtons[i].addActionListener(addNumber);
            numbers.add(numberButtons[i]);
        }
        
        numberButtons[0] = new JButton("0");
        numberButtons[0].addActionListener(addNumber);
        JButton starButton = new JButton("*");
        JButton hashButton = new JButton("#");
        
        numbers.add(starButton);
        numbers.add(numberButtons[0]);
        numbers.add(hashButton);
        
        JButton callButton = new JButton("call");
        numbers.add(new JLabel());
        numbers.add(callButton);
        
        // create south panel
        JPanel south = new JPanel();
        add(south, BorderLayout.SOUTH);
        
        // create components for south
        JButton favButton = new JButton("(f)");
        JButton recButton = new JButton("(r)");
        JButton conButton = new JButton("(c)");
        JButton keyButton = new JButton("(k)");
        JButton voiButton = new JButton("(v)");
        
        south.add(favButton);
        south.add(recButton);
        south.add(conButton);
        south.add(keyButton);
        south.add(voiButton);      
        
        
        setVisible(true);
    }
    
    private void renderNumbers() {
        numberLabel.setText(numbers);
    }
    
    private void addToNumbers(String number) {
        if (numbers.length() > 15) {
            return;
        }
        numbers += number;
        renderNumbers();
    }

    private void removeFromNumbers() {
//        numbers = numbers.sub;
//        renderNumbers();
    }
    

}
