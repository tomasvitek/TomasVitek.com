import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Phone extends JFrame
{

    private String numbersContent = "";
    private JLabel numbers;
    
    public Phone() {
        setTitle("O2-UK    19:26    33%");
        setSize(400, 700);
        
        JPanel north = new JPanel();
        JPanel center = new JPanel();
        JPanel south = new JPanel();
        
        setLayout(new BorderLayout());
        
        add(north, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);
        
        // components top panel
        
        JButton addContactButton = new JButton("(+)");
        JButton deleteButton = new JButton("(<)");
        numbers = new JLabel("020 00239042348");
        renderNumbers();
        
        north.setLayout(new BorderLayout());
        north.add(addContactButton, BorderLayout.WEST);
        north.add(numbers, BorderLayout.CENTER);
        north.add(deleteButton, BorderLayout.EAST);
        
        // center
        
        center.setLayout(new GridLayout(5, 3));
        JButton[] numberButtons = new JButton[10];
        
        ActionListener addNumber = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton)e.getSource();
                addToNumbers(source.getText());
            }
        };
        
        for (int i = 1; i < 10; i++) {
            numberButtons[i] = new JButton(""+i);
            center.add(numberButtons[i]);
            numberButtons[i].addActionListener(addNumber);
            
        }
        
        JButton starButton = new JButton("(*)");
        JButton hashButton = new JButton("(#)");
        numberButtons[0] = new JButton("0");
        
        numberButtons[0].addActionListener(addNumber);
        starButton.addActionListener(addNumber);
        hashButton.addActionListener(addNumber);
        
        center.add(starButton);
        center.add(numberButtons[0]);
        center.add(hashButton);
        
        JButton callButton = new JButton("(call)");
        center.add(new JLabel());
        center.add(callButton);
        
        
        

        
        setVisible(true);
    }
    
    private void renderNumbers() {
        numbers.setText(numbersContent);
    }
    
    private void addToNumbers(String toAdd) {
        numbersContent += toAdd;
        renderNumbers();
    }
}
